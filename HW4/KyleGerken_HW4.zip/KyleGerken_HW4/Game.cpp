#include "Game.h"
//***************************************************************************************
// File: Game.cpp
//
// Purpose: Definitions for Class member functions. Creates Game, identified with Title,ESRB,Price.
//			**Update to Unsorted List.
//
// Written By: Kyle Gerken
//
// Compiler: Visual C++ 2019
//
// Update Information:
// -----------------------------
// Name: Kyle Gerken
// Date: 10/29/2021 -- Original version used form HW1 / HW2.
// 
// Description: 	
//		- Created Private member variables: Title, ESRB, and Price
//		- Created appropriate Set/Get methods
//		- Overloaded "operator=" and "operator<<"  for appropriate object usage
// 
// Name: Kyle Gerken
// Date: 10/30/2021
// Description:
//		- Changed Game class into an Unsorted Linked list class for HW3. Updated From
//		  HW1,HW2.
//
//***************************************************************************************

//*****************************************************
// Function: Game Default Constructor
// 
// Purpose: Initialize member variables of Game to default values
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
// 
//*****************************************************
Game::Game() {
	
	m_title = "NoTitle";

	m_esrb = "NoESRB";

	m_price = 0.0;
}



//*****************************************************
// Function: Game Paramterized Constructor
// 
// Purpose: Initialize member variables passed in from initialized Class Object
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10/29/2021
// Description:	Paramterized Constructor modified for dynamic allocation of member variables set to pointers.
//*****************************************************
Game::Game(std::string title, std::string esrb, double price)
{
	m_title = title;

	m_esrb = esrb;

	m_price = price;
}



//*****************************************************
// Function: Game Copy Constructor
// 
// Purpose: Deep copy of Game object values passed into paramter. Writes over default member values.
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
Game::Game(const Game& copy)
{	//Deep copy of member variables
	
	m_title = copy.m_title;

	
	m_esrb = copy.m_esrb;

	
	m_price = copy.m_price;
}



//*****************************************************
// Function: Game Destructor
// 
// Purpose: Deallocates new member variables initialized from constructors
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
Game::~Game() {

}



//*****************************************************
// Function: setTitle
// 
// Purpose: Changes value of Title
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
void Game::SetTitle(std::string title) {
	m_title = title;
}


//*****************************************************
// Function: Set member function: ESRB
// 
// Purpose: Changes value of ESRB
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
void Game::SetEsrb(std::string esrb)
{
	m_esrb = esrb;
}

//*****************************************************
// Function: Set member function: Price
// 
// Purpose: Changes value of Price
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
void Game::SetPrice(double price) {
	m_price = price;
}



//*****************************************************
// Function: Get member function: Title
// 
// Purpose: Returns value of Game:Title
// 
// Update Information:
// ------------------------------------------
//Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
std::string Game::GetTitle()
{
	return m_title;
}


//*****************************************************
// Function: Get member function: ESRB
// 
// Purpose: Returns value of Game:ESRB
// 
// Update Information:
// ------------------------------------------
//Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
std::string Game::GetEsrb()
{
	return m_esrb;
}


//*****************************************************
// Function: Get member function: Price
// 
// Purpose: Returns value of Game:Price
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
double Game::GetPrice()
{
	return m_price;
}


//*****************************************************
// Function: Assignment Operator Member Overlaod
// 
// Purpose: Overloads operator= to assign one game object passed by reference to other
//			game object
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
Game& Game::operator=(const Game& rhs)
{
	if (this == &rhs)
	{	//returns dereferenced "this"
		return *this;
	}

	this->m_title = rhs.m_title;
	this->m_esrb = rhs.m_esrb;
	this->m_price = rhs.m_price;

	return *this;
}





//*****************************************************
// Function: Extraction Operator Non-Member Overlaod
// 
// Purpose: Overloads extraction operator "operator<<" to output game objects to console 
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
std::ostream& operator<<(std::ostream& os, const Game& g)
{
	os << "Title: " << g.m_title << std::endl;
	os << "ESRB: " << g.m_esrb << std::endl;
	os << std::fixed << std::setprecision(2) << "Price: $ " << g.m_price << std::endl;

	return os;
}


//*****************************************************
// Function: operator>>
// 
// Purpose: Overloads insertion operator " >> " as non-member overload to take input directly from user
//			to apply change member values 
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 10 / 29 / 2021 
// Description: Original version used form HW1 / HW2.
//*****************************************************
std::istream& operator>>(std::istream& is, Game& rhs)
{
	is >> rhs.m_title >> rhs.m_esrb >> rhs.m_price;

	return is;
}



//*****************************************************
// Function: operator<
// 
// Purpose: Non-Member Overload for the less than operator. Function returns the VALUE of the 'lhs' Title (Data not pointer) is less than the 'rhs' title. 
//			Return False oterhwise.
//			
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 12/5/2021
// Description: Added for HW 3
//*****************************************************
bool operator<(Game& lhs, Game& rhs) {
	if (lhs.m_title < rhs.m_title) {
		return true;
	}
	else {
		return false;
	}
}



//*****************************************************
// Function: operator>
// 
// Purpose: Non-Member Overload for the greater than operator. Function shopuld return true if the VALUE of the title (this means the data not the pointer) 
//			is greater thann the rhs title. Return False otherwise
//			
// 
// Update Information:
// ------------------------------------------
// Name: Kyle Gerken
// Date: 12/5/2021
// Description: Added for HW 3
//*****************************************************
bool operator>(Game& lhs, Game& rhs) {
	if (lhs.m_title > rhs.m_title) {
		return true;
	}
	else {
		return false;
	}
}